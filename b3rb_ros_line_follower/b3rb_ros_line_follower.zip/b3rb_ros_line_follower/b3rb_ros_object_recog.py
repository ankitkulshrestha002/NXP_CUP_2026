# Copyright 2024-2026 NXP
# Licensed under the Apache License, Version 2.0

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
from std_msgs.msg import String
import cv2
import numpy as np
import os
from collections import deque
from ament_index_python.packages import get_package_share_directory

# 100% LEGAL FOR COMPETITION - NO ULTRALYTICS
import tflite_runtime.interpreter as tflite 

BOARD_LAYOUT = ['A', 'B', 'C', 'X', 'Y', 'Z']

class ObjectRecognizer(Node):
    """
    ROS 2 Node that detects Green Overhead Signboards.
    Uses Homography Unwarping + Your Newly Trained YOLOv8 TFLite Classifier!
    """
    def __init__(self):
        super().__init__('object_recognizer')

        self.subscription_camera = self.create_subscription(
            CompressedImage,
            '/camera/image_raw/compressed',
            self.camera_image_callback,
            10)

        self.publisher_sign = self.create_publisher(
            String,
            '/sign_board_detection',
            10)

        # Your excellent Rolling History Buffer (Deque)
        self.history = {letter: deque(maxlen=12) for letter in BOARD_LAYOUT}
        self.CONFIRM_THRESHOLD = 10

        # ====================================================
        # LOAD YOUR NEWLY TRAINED TFLITE CLASSIFIER
        # ====================================================
        try:
            package_share_directory = get_package_share_directory('b3rb_ros_line_follower')
            
            # Make sure you renamed your downloaded file to NXP_CUP.tflite!
            model_path = os.path.join(package_share_directory, 'nxpcup.tflite')
            
            self.get_logger().info(f"Loading TFLite model from: {model_path}...")
            
            self.interpreter = tflite.Interpreter(model_path=model_path)
            self.interpreter.allocate_tensors()
            
            self.input_details = self.interpreter.get_input_details()
            self.output_details = self.interpreter.get_output_details()
            
            self.get_logger().info("✅ TFLite Model Loaded Successfully!")
        except Exception as e:
            self.get_logger().error(f"❌ Failed to load TFLite model: {e}")
            self.interpreter = None
            
        self.get_logger().info("🚀 Object Recognizer Active (TFLite Classifier + Rolling Buffer Mode).")

    def camera_image_callback(self, message):
        if self.interpreter is None:
            return

        np_arr = np.frombuffer(message.data, np.uint8)
        image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        if image is None: return

        # Get the detections for this frame using Unwarping + TFLite
        seen_this_frame = self.process_sign_board(image)

        # Update History Buffer
        for letter in BOARD_LAYOUT:
            dir_seen = seen_this_frame.get(letter, None)
            self.history[letter].append(dir_seen) 
            
            left_count = self.history[letter].count("LEFT")
            right_count = self.history[letter].count("RIGHT")
            straight_count = self.history[letter].count("STRAIGHT")
            
            best_dir = None
            if left_count >= self.CONFIRM_THRESHOLD:
                best_dir = "LEFT"
            elif right_count >= self.CONFIRM_THRESHOLD:
                best_dir = "RIGHT"
            elif straight_count >= self.CONFIRM_THRESHOLD:
                best_dir = "STRAIGHT"
            
            # Publish if threshold met
            if best_dir is not None:
                msg = String()
                msg.data = f"{letter}_{best_dir}"
                self.publisher_sign.publish(msg)
                self.get_logger().info(f"📡 CONFIRMED SIGN: {letter}_{best_dir}")
                self.history[letter].clear()

    def unwarp_signboard(self, image, contour, num_panels):
        """Flattens the slanted green board so we can crop perfect squares"""
        try:
            rect = cv2.minAreaRect(contour)
            box = cv2.boxPoints(rect)
            box = np.float32(box)

            indices = np.argsort(box[:, 1])
            top_two = box[indices[:2]]
            bottom_two = box[indices[2:]]

            tl = top_two[np.argmin(top_two[:, 0])]
            tr = top_two[np.argmax(top_two[:, 0])]
            bl = bottom_two[np.argmin(bottom_two[:, 0])]
            br = bottom_two[np.argmax(bottom_two[:, 0])]

            src_pts = np.array([tl, tr, br, bl], dtype=np.float32)

            target_w = 100 * num_panels
            target_h = 120
            
            dst_pts = np.array([
                [0, 0],
                [target_w - 1, 0],
                [target_w - 1, target_h - 1],
                [0, target_h - 1]
            ], dtype=np.float32)

            M = cv2.getPerspectiveTransform(src_pts, dst_pts)
            unwarped = cv2.warpPerspective(image, M, (target_w, target_h))
            return unwarped
        except Exception:
            return None

    def classify_arrow_crop(self, arrow_crop):
        """Your newly trained 224x224 TFLite ML Arrow Classifier"""
        try:
            img_rgb = cv2.cvtColor(arrow_crop, cv2.COLOR_BGR2RGB)
            
            # 1. Resize to match the 224x224 YOLO Classification model
            img_resized = cv2.resize(img_rgb, (224, 224))
            
            # 2. Normalize to float32 (0.0 to 1.0)
            img_normalized = img_resized.astype(np.float32) / 255.0
            
            # 3. FIX THE SHAPE: Convert from (224, 224, 3) to (3, 224, 224) (BCHW format)
            img_transposed = np.transpose(img_normalized, (2, 0, 1))
            
            # 4. Add batch dimension -> Shape becomes (1, 3, 224, 224)
            img_expanded = np.expand_dims(img_transposed, axis=0)
                
            # 5. Run inference
            self.interpreter.set_tensor(self.input_details[0]['index'], img_expanded)
            self.interpreter.invoke()
            
            output_data = self.interpreter.get_tensor(self.output_details[0]['index'])
            probabilities = output_data[0] 
            
            class_id = int(np.argmax(probabilities))
            max_prob = probabilities[class_id]
            
            # CHECK THIS AGAINST YOUR ROBOFLOW DATASET
            classes = ["LEFT", "RIGHT", "STRAIGHT"] 
            
            if max_prob > 0.60:
                return classes[class_id]

        except Exception as e:
            self.get_logger().error(f"Inference Error: {e}") 
        return None

    def process_sign_board(self, image):
        detected_in_frame = {} 
        img_h, img_w = image.shape[:2]
        
        # 1. Find the Green Board
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, np.array([35, 50, 50]), np.array([85, 255, 255]))
        
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            aspect_ratio = float(w) / max(h, 1)

            if aspect_ratio >= 3.5:
                MIN_BOARD_WIDTH = int(img_w * 0.60)
                layouts = [BOARD_LAYOUT]
                num_panels = 6
            else:
                MIN_BOARD_WIDTH = int(img_w * 0.45)
                layouts = [['A', 'B', 'C'], ['X', 'Y', 'Z']]
                num_panels = 3

            MAX_BOARD_WIDTH = int(img_w * 0.85)

            if MIN_BOARD_WIDTH < w < MAX_BOARD_WIDTH and y > 8 and aspect_ratio > 1.8:
                
                # 2. Unwarp it so we can chop it up
                flat_board = self.unwarp_signboard(image, contour, num_panels)
                if flat_board is None: continue
                
                panel_w = 100 
                for i in range(num_panels):
                    panel = flat_board[:, i*panel_w : (i+1)*panel_w]
                    
                    # 3. Crop just the arrow part (bottom 42%)
                    mid_y = int(panel.shape[0] * 0.58)
                    arrow_crop = panel[mid_y:, :] 

                    # 4. SEND TO YOUR NEW AI!
                    direction = self.classify_arrow_crop(arrow_crop)
                    
                    if direction is not None:
                        for layout in layouts:
                            letter = layout[i]
                            detected_in_frame[letter] = direction
                            
        return detected_in_frame

def main(args=None):
    rclpy.init(args=args)
    node = ObjectRecognizer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()